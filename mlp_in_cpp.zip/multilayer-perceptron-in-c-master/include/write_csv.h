#ifndef WRITE_CSV_H
#define WRITE_CSV_H

#include <cstdio>
#include <cstdlib>
#include <cstring>

void write_csv(char*, int, int, double**);

#endif