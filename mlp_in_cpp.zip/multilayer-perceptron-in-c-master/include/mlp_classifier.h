#ifndef MLP_CLASSIFIER_H
#define MLP_CLASSIFIER_H

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include "read_csv.h"
#include "write_csv.h"
#include "parameters.h"

void mlp_classifier(parameters*, int*);

#endif