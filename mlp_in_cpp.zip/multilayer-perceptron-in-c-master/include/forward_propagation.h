#ifndef FORWARD_PROPAGATION_H
#define FORWARD_PROPAGATION_H

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include "parameters.h"

void forward_propagation(parameters*, int, int, int*, double**, double**);

#endif