#ifndef MLP_TRAINER_H
#define MLP_TRAINER_H

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include "forward_propagation.h"
#include "back_propagation.h"
#include "parameters.h"

void mlp_trainer(parameters* param, int*);

#endif