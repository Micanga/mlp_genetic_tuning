#ifndef BACK_PROPAGATION_H
#define BACK_PROPAGATION_H

#include <cstdio>
#include <cstdlib>
#include "parameters.h"

void back_propagation(parameters*, int, int, int*, double**, double**);

#endif